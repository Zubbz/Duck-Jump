I would like to thank PsychoLucidia, Ayatotsu, RimiRimsss, TomokiTGB, and Quickblade
gor helping me fix some codes in the game. This is my first game made, so expect some
imperfections. Please enjoy.